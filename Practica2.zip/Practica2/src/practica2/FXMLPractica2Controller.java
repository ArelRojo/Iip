/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica2;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.Circle;

/**
 *
 * @author lisas
 */
public class FXMLPractica2Controller implements Initializable {
    
  
    @FXML
    private Circle circle;
    @FXML
    private GridPane grid;
    
    int x_Circle, y_Circle;
    int size_x, size_y;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        size_y = grid.getRowConstraints().size();
        size_x = grid.getColumnConstraints().size();
        x_Circle = y_Circle = 2;
        circle.requestFocus();
    }    

    @FXML
    private void moveCircle(KeyEvent event) {
        KeyCode key = event.getCode();
        if(key==KeyCode.UP){
            y_Circle=(y_Circle-1 + size_y) %size_y;
            grid.setRowIndex(circle,y_Circle);
             
            
        }else if(key==KeyCode.DOWN){
            y_Circle=(y_Circle+1 + size_y) %size_y;
            grid.setRowIndex(circle,y_Circle);
            
        }else if(key==KeyCode.LEFT){
            x_Circle=(x_Circle-1 + size_x)%size_x;
            grid.setColumnIndex(circle, x_Circle);
        
        }else if(key==KeyCode.RIGHT){
            x_Circle=(x_Circle+1 + size_x)%size_x;
            grid.setColumnIndex(circle, x_Circle);
    }
    }
        

    
   
}
