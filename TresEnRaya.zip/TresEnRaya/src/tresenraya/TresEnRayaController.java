/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tresenraya;

import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

import javafx.scene.layout.GridPane;

/**
 *
 * @author lisas
 */
public class TresEnRayaController implements Initializable {
    
    @FXML
    private GridPane grid;
    private boolean esJugador1 = true;
    private int jugadas = 9;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void metIniciar(ActionEvent event) {
        for(Iterator iterator = grid.getChildren().iterator(); iterator.hasNext();){
            Button boton = (Button)iterator.next();
        boton.setText("");}
        grid.setDisable(false);
        jugadas = 9;
        esJugador1 = true;
    }

    @FXML
    private void jugar(ActionEvent event) {
        Button pulsado = (Button) event.getSource();
        if(pulsado.getText()== ""){
            if(esJugador1){
                pulsado.setText("X");
                esJugador1 = false;
            }else {
                pulsado.setText("O");
                    esJugador1 = true;
            }
            jugadas--;
            if(jugadas == 0){}
        }
    }
    
}
